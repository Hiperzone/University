﻿using UnityEngine;
using System.Collections;
using AssemblyCSharp;
public class GoCubo : MonoBehaviour {
	
	private bool m_tempoViradoTrigger = false;
	private float m_tempoVirado = 0;
	//define o tipo de peca que esta presente neste cubo
	//ex: armadilha, osso
	private CubeProperties m_Propriedades;
	public CubeProperties Propriedades
	{
		get { return m_Propriedades; }
		set { m_Propriedades = value;}
	}

	private System.Random rnd;

	
	//materiais
	public Material[] Ossos;
	public Material[] Minhocas;
	public Material SemNada;

	private GameObject m_GameLogic; //Instancia da classe que controla a logica do jogo.
	
	//variavel que contem o estado relacionado com a visualizacao da imagem
	//associado a este objecto quando o jogador clica no cubo.
	private bool virado = false;
	
	public GoCubo()
	{
		rnd = new System.Random((int)System.DateTime.Now.Ticks);
	}


	public void setVirado(bool virado)
	{
		this.virado = virado;
		Debug.Log("Cubo Virado");
	}
	
	public bool getVirado()
	{
		return virado;
	}
	
	// Use this for initialization
	void Start () {
		m_GameLogic = GameObject.Find("GameLogic");
	}
	
	// Update is called once per frame
	void Update () {
		//animacao que mostra o conteudo escondido do cubo por n tempo e volta a virar.
		if(m_tempoViradoTrigger)
		{
			m_tempoVirado -= UnityEngine.Time.deltaTime;
		}
		if( m_tempoViradoTrigger && m_tempoVirado <= 0)
		{
			m_tempoViradoTrigger = false;
			m_tempoVirado = 0;
			setVirado(false);
		}
	}
	
	public void SetObjectiveColor()
	{
		Debug.Log ("Cor do cubo atribuida");
		if(m_Propriedades.tipo == GoType.GO_TIPO_OSSO)
		{
		renderer.material.color = Propriedades.cor;
		}
	}

	public void SetMaterial()
	{
		//escolher o material aleatoriamente
		if(m_Propriedades.tipo == GoType.GO_TIPO_OSSO)
		{
			renderer.material = Ossos[rnd.Next ( Ossos.Length )];
		}
		else if(m_Propriedades.tipo == GoType.GO_TIPO_OSSO_FALSO)
		{
			renderer.material = Minhocas[rnd.Next ( Minhocas.Length )];
		}
		else if(m_Propriedades.tipo == GoType.GO_TIPO_EMPTY)
		{
			//material por defeito
		}


	}
	
	public void VirarOnTimer(float time)
	{
		m_tempoViradoTrigger = true;
		m_tempoVirado = time;
		animation.Play("CuboAnimShowBones");
		virado = true;
	}
	
	void OnMouseDown ()
	{
		Debug.Log ("Jogador clicou no cubo");
		if(!virado)
		{
			animation.Play("CuboAnimRotacao180G");

		}
		GameController c = (GameController)m_GameLogic.GetComponent(typeof(GameController));
		Debug.Log("Evento: Jogador clicou no cubo");
		c.PlayerClickedCube(this);
	}
	
	void OnDestroy ()
	{
		Debug.Log("Object destruction evoked");
		DestroyImmediate(renderer.material);
	}

}
