﻿using UnityEngine;
using System.Collections;
using AssemblyCSharp;

public class GameController : MonoBehaviour {
	
	public enum GAMESTATE
	{
		GAMESTATE_NOT_PLAYING,
		GAMESTATE_PLAYING,
		GAMESTATE_NEW_LEVEL,
		GAMESTATE_GAMEOVER,
		GAMESTATE_WON
	};
	
	public GameObject[,] m_grelha;

	private int m_width = 1;
	private int m_height = 1;
	private int max_width = 10;
	private int max_height = 6;
	DifficultyControllerI m_DifficultyController;
	public int m_currLevel = 0;
	private int m_maxLevels = 9;
	public GAMESTATE m_GameState = GAMESTATE.GAMESTATE_PLAYING;
	public int m_numObjectivesTillCompletation = 0;



	//variaveis finais
	public int NumVidas = 3;
	public int m_dificuldade = 0;
	public Texture tGameover;
	public Texture tVida;
	public Texture tOssos;
	public Texture tSom;
	public Texture tCao;
	public Texture tVitoria;
	public int ossosEncontrados = 0;

	public GameObject m_prefabCube_Empty;

	public GameObject m_prefabCubeOssos;

	public Transform background;
	public Transform cam;

	
	void OnGUI()
	{
		//desenhar o interface
		GUI.DrawTexture(new Rect(1250,4,109,34), tSom);

		GUIStyle style = new GUIStyle();
		style.fontSize = 42;
		style.normal.textColor = Color.white;
		GUI.Label(new Rect(150, 0, 200, 200), ossosEncontrados.ToString() , style);
		GUI.DrawTexture(new Rect(250,4,72,34), tVida);
		GUI.DrawTexture(new Rect(50,4,96,34), tOssos);
		GUI.DrawTexture(new Rect(50,409,256,359), tCao);
		GUI.Label(new Rect(325, 0, 200, 200), NumVidas.ToString(), style);

		if(NumVidas == 0)
		{
			int x = Screen.width / 2;
			x-= 814 / 2;
			int y = Screen.height / 2   - 117/2;
			GUI.DrawTexture(new Rect(x,y,814,117), tGameover);
		}
		if(m_currLevel >= m_maxLevels)
		{
			int x = Screen.width / 2;
			x-= 1031 / 2;
			int y = Screen.height / 2   - 155/2;
			GUI.DrawTexture(new Rect(x,y,1031,155), tVitoria);
		}
	}

	void Awake()
	{
	}
	
	// Use this for initialization
	void Start () {
		//switch de dificuldade aqui mais tarde
		if(m_dificuldade == 0)
		{
			Debug.Log ("Instanciado o nivel de dificuldade");
			m_DifficultyController = new DifficultyColorMatchController();
		}
	}
	
	void ReturnToMainMenu()
	{
		Application.LoadLevel("inicio_e_menu");

	}
	// Update is called once per frame
	void Update () {
		
		if(m_GameState == GAMESTATE.GAMESTATE_NOT_PLAYING)
		{

		}
		else if( m_GameState == GAMESTATE.GAMESTATE_PLAYING)
		{
			if(NumVidas == 0)
			{
				m_GameState = GAMESTATE.GAMESTATE_GAMEOVER;
			}
			//verificar os cubos ja virados
			if(m_numObjectivesTillCompletation == 0)
			{
				for(int y=0; y < m_height; y++)
				{
					for(int x=0; x < m_width; x++)
					{
						if(m_grelha != null)
						{
							GoCubo cubo = (GoCubo)m_grelha[x,y].GetComponent(typeof(GoCubo));
							if(cubo && cubo.animation.IsPlaying("CuboAnimRotacao180G"))
							{
								return;
							}
						}
					}

				}
				//objectivos ja foram alcancados, destruir o nivel e passar ao proximo se possivel.

				if(m_currLevel >= (m_maxLevels))
				{
					m_GameState = GAMESTATE.GAMESTATE_WON;
				}
				else
				{
					m_GameState = GAMESTATE.GAMESTATE_NEW_LEVEL;
				}
			}

			//jogador gastou as vidas

			if(m_GameState == GAMESTATE.GAMESTATE_GAMEOVER)
			{
				//esperar 5segundos antes de voltar ao ecra
				animation.Play("GoToMainMenu5s");
				m_GameState = GAMESTATE.GAMESTATE_NOT_PLAYING;
			}
		}
		else if(m_GameState == GAMESTATE.GAMESTATE_WON)
		{
			animation.Play("GoToMainMenu5s");
			m_GameState = GAMESTATE.GAMESTATE_NOT_PLAYING;
			
		}
		else if( m_GameState == GAMESTATE.GAMESTATE_NEW_LEVEL)
		{
			print (m_GameState);
			Debug.Log (m_currLevel);
			//destroir o nivel.
			DestroyGrid();
			//incrementar o nivel
			m_currLevel = m_currLevel + 1;
			if(m_currLevel >= (m_maxLevels))
			{
				m_GameState = GAMESTATE.GAMESTATE_WON;
				return;
			}
			if((m_width + 1) < max_width)
				m_width = m_width + 1;
			if((m_height + 1) < max_height)
				m_height = m_height + 1;
			m_DifficultyController.GenerateObjectivesPool(m_width, m_height);
			m_numObjectivesTillCompletation = m_DifficultyController.getNumObjectives();
			//gerar o nivel.
			m_grelha = new GameObject[m_width, m_height];
			initializeGrid(m_width, m_height);
			
			m_GameState = GAMESTATE.GAMESTATE_PLAYING;
			TurnAllCubes();
		}
	}
	
	void TurnAllCubes()
	{
		Debug.Log ("Voltando todos os cubos");
		for(int y=0; y < m_height; y++)
		{
			for(int x=0; x < m_width; x++)
			{
				GoCubo cubo = (GoCubo)m_grelha[x,y].GetComponent(typeof(GoCubo));
				cubo.VirarOnTimer(4);
			}
		}
	}
	
	void DestroyGrid()
	{
		if(m_grelha != null)
		{
			Debug.Log("Destruindo o conteudo da grelha");
			for(int y=0; y < m_height; y++)
			{
				for(int x=0; x < m_width; x++)
				{
					if(m_grelha[x,y])
						Destroy(m_grelha[x,y]);
					m_grelha[x,y] = null;
				}
			}
		}
	}
	
	/**
	 * Geracao da grealha
	 * 
	 */
	void initializeGrid(int w, int h)
	{
		Debug.Log("Inicializando a grelha do jogo");
		float offset_cubo_x = 0.0f; //distancia de um cubo ao outro nas linhas
		float offset_cubo_y = 0.0f; //distancia de um cubo ao outro nas colunas
		float offset_x = 0.035f;
		float offset_y = -0.035f;

		float origem_x = 0 - w;
		float origem_y = 0 + h;
		float cmoffset_x=0;
		float cmoffset_y=0;

		for(int y=0; y < h; y++)
		{
			offset_x = -0.0008669501f*(w/2.0f);
			offset_x-= 0.04f*(w/2.0f);
			offset_x += 0.015f;
			for(int x=0; x < w; x++)
			{
				//offset_y = offset_y + 0.0f;
				Vector3 pos = new Vector3(offset_x,offset_y,-2);
				GameObject newObj = (GameObject)GameObject.Instantiate(m_prefabCube_Empty,pos,Quaternion.identity);
				m_grelha[x, y] = newObj;
				GoCubo cubo = (GoCubo)m_grelha[x,y].GetComponent(typeof(GoCubo));
				cubo.setVirado(false);

				CubeProperties PropriedadesCubo = m_DifficultyController.getObjectiveFromPool();
				cubo.Propriedades = PropriedadesCubo;
				cubo.SetMaterial();


				offset_x = offset_x + 0.04f+0.0008669501f;
				cmoffset_x = pos.x*(1.0f/(w*h));
				cmoffset_y = pos.y*(1.0f/(w*h));
			}
			offset_y=offset_y+0.04f+0.0008669501f;
			Debug.Log(offset_y);
		}
		float center = 0.04f*h;
		center=0.15f;
		cam.position= new Vector3(cmoffset_x,cmoffset_y+center,cam.position.z);
		background.position= new Vector3(cmoffset_x,cmoffset_y-0.2477965f+center,background.position.z);
		/*
		float offsetx = 0; 
		float offsety = 0;
		float offsetx2 = 0;
		float offsety2 = 0;
		
		if(w % 2 == 0)
		{
			offsetx2 = 1;
			offsety2 = 0.5f;
		}
		else
		{
			offsetx2 = 0.5f;
			offsety2 = 0f;
		}
		
		for(int y=0; y < h; y++)
		{
			if(y > 0) 
			{
				offsety = y + y*0.1f;
			}
			
			for(int x=0; x < w; x++)
			{
				if(x > 0) 
				{
					offsetx = x + x*0.1f;
				}
				Debug.Log (offsetx - w/2 + 1);
				m_grelha[x, y] = (GameObject)Instantiate(m_prefabCube_Empty,new Vector3((offsetx - w/2 + offsetx2), (offsety - h/2 + offsety2),0), Quaternion.identity);
				GoCubo cubo = (GoCubo)m_grelha[x,y].GetComponent(typeof(GoCubo));
				cubo.setVirado(false);
				CubeProperties PropriedadesCubo = m_DifficultyController.getObjectiveFromPool();
				cubo.Propriedades = PropriedadesCubo;
				cubo.SetObjectiveColor();
			}
			offsetx = 0;
			offsety = 0;
		}
		*/
	}		



	public void PlayerClickedCube(GoCubo c)
	{
		if(NumVidas > 0 && m_GameState == GAMESTATE.GAMESTATE_PLAYING)
		{
			Debug.Log("PlayerClickedCube");
			if(!c.getVirado() )
			{
				if(c.Propriedades.tipo == GoType.GO_TIPO_OSSO)
				{
					m_numObjectivesTillCompletation -= 1;
					ossosEncontrados += 1;


				}

				if(c.Propriedades.tipo == GoType.GO_TIPO_OSSO_FALSO ||c.Propriedades.tipo == GoType.GO_TIPO_EMPTY)
				{
					if(NumVidas > 0)
					{
						NumVidas -=1;
					}
				}
				c.setVirado(true);
			}
		}
	}
	
	
	
}