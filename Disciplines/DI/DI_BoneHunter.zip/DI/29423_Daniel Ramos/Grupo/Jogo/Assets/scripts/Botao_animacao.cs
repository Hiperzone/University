﻿using UnityEngine;
using System.Collections;

public class Botao_animacao : MonoBehaviour {

	public MainMenuController.MENU_STATE accao = MainMenuController.MENU_STATE.MENU_STATE_NONE;
	public AnimationClip animClip;
	Animator _animation;
	public Material onMouseOutTextureMaterial;
	public Material OnMouseOverTextureMaterial;
	public Vector3 originalCoords;
	public bool useAnimation = false;
	// Use this for initialization
	void Start () 
	{
		if(useAnimation)
		{
			animation.Play(animClip.name);
		}

	}
	
	// Update is called once per frame
	void Update () {

	}

	void OnMouseDown ()
	{
		GameObject _obj = GameObject.Find("menu_inicial_modelo");
		if(_obj)
		{
			MainMenuController _script = _obj.GetComponent<MainMenuController>();
			_script.State = accao;
		}

	}

	void OnMouseOver()
	{
		renderer.material = OnMouseOverTextureMaterial;


	}

	void OnMouseExit()
	{
		renderer.material = onMouseOutTextureMaterial;
		Debug.Log("OnMouseExit");



	
	}
}
