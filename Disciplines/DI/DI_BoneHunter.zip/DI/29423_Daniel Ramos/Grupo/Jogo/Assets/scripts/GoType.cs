using System;

namespace AssemblyCSharp
{
	public enum GoType
	{
		GO_TIPO_EMPTY       = 0x00,
		GO_TIPO_OSSO        = 0x01,
		GO_TIPO_ARMADILHA   = 0x02,
		GO_TIPO_OSSO_FALSO  = 0x04,
		GO_TIPO_COLOR_MATCH = 0x08
	}
}

