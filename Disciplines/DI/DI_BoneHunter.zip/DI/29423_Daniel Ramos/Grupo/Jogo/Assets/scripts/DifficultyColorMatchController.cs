using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
namespace AssemblyCSharp
{
	/**
	 * Dificuldade - Easy - Color match aleatoria por osso
	 * Numero de objectivos = max(Tamanho da grelha em X, Tamanho da grelha em Y) / 2
	 * 
	 **/
	public class DifficultyColorMatchController : DifficultyControllerI
	{
		private List<CubeProperties> m_generatedObjectiveList;
		private System.Random rnd;
		private int m_gridSizeX = 0;
		private int m_gridSizeY = 0;
		
		public DifficultyColorMatchController ()
		{
			rnd = new System.Random((int)System.DateTime.Now.Ticks);
		}
		
		/**
		 * Geracao da quantidade de objectivos por tamanho de grelha.
		 **/
		public void GenerateObjectivesPool(int gridSizeX, int gridSizeY)
		{
			int numColors = 1; //numero de cores diferentes.
			int numPerColor = Math.Max(gridSizeX, gridSizeY) ; //numero de quadrados por cor
			m_gridSizeX = gridSizeX;
			m_gridSizeY = gridSizeY;
			int numMinhocas = Math.Max(gridSizeX - 2, gridSizeY - 2) ; //numero de minhocas por grid, 2x2 n gera nada


			
			//initializar a lista
			if(m_generatedObjectiveList != null)
				m_generatedObjectiveList.Clear();
			m_generatedObjectiveList = new List<CubeProperties>();



			//inserir quadrados neutros.
			for(int i = 0; i < (gridSizeX*gridSizeY - numPerColor - numMinhocas); i++)
			{
				CubeProperties obj = new CubeProperties( );
				obj.cor = Color.gray;
				obj.tipo = GoType.GO_TIPO_EMPTY;
				
				m_generatedObjectiveList.Add(obj);
			}
		
			//numero de quadrados com minhocas
			for(int i = 0; i < numMinhocas; i++)
			{
				CubeProperties obj = new CubeProperties( );
				obj.cor = Color.yellow;
				obj.tipo = GoType.GO_TIPO_OSSO_FALSO;
				m_generatedObjectiveList.Add(obj);
			}

			//gerar os ossos
			for(int i = 0; i < numColors; i++)
			{
				for(int j = 0; j < numPerColor; j++)
				{
					CubeProperties obj = new CubeProperties( );
					obj.cor = Color.yellow;
					obj.tipo = GoType.GO_TIPO_OSSO;
					m_generatedObjectiveList.Add(obj);
				}
			}
		}
		
		public CubeProperties getObjectiveFromPool()
		{
			int index = rnd.Next ( m_generatedObjectiveList.Count );
			CubeProperties obj = m_generatedObjectiveList[index];
			m_generatedObjectiveList.RemoveAt(index);
			return obj;
		}
		
		public int getNumObjectives()
		{
			return 	Math.Max(m_gridSizeX, m_gridSizeY);
		}
	}
}

