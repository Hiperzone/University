﻿using UnityEngine;
using System.Collections;

public class GUIController : MonoBehaviour {
	
	public enum GUI_RENDER_TARGET
	{
		GUI_RENDER_NONE,
		GUI_RENDER_PLAYING_UI
		
	};
	private GUI_RENDER_TARGET m_guiRenderId = GUI_RENDER_TARGET.GUI_RENDER_PLAYING_UI;
	
	public GUI_RENDER_TARGET GuiRenderId
	{
		set 
		{
			m_guiRenderId = value;
		}
		
		get
		{
			return m_guiRenderId;
		}
	}
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		
		if(Input.GetKeyDown(KeyCode.C))
		{
			animation.Play("CubeAnimRotate180");	
		}
		
		if(Input.GetKeyDown(KeyCode.H))
		{
			animation.Play("CubeAnimCredits");	
		}

		if(Input.GetKeyDown(KeyCode.Return))
		{
			animation.Play("CubeAnimMainIdle");
		}
	
		
	}
	 
	void RenderGameMainUI()
	{
		
		
	}
	
	void OnGUI () 
	{
		if(m_guiRenderId == GUI_RENDER_TARGET.GUI_RENDER_PLAYING_UI)
		{
			/*if (GUI.Button (new Rect (10,10,150,100), "I am a button")) 
			{
				m_guiRenderId = GUI_RENDER_TARGET.GUI_RENDER_NONE;
			}*/

		}
		
		
	}
}