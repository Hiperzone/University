﻿using UnityEngine;
using System.Collections;

public class MainMenuController : MonoBehaviour {
	public enum MENU_STATE
	{
		MENU_STATE_NONE,
		MENU_STATE_HELP,
		MENU_STATE_ABOUT,
		MENU_STATE_PLAY,
		MENU_STATE_HELP_TO_MAIN,
		MENU_STATE_CREDITS_TO_MAIN
	};
	private MENU_STATE m_MenuState = MENU_STATE.MENU_STATE_NONE;
	public MENU_STATE State
	{
		get { return m_MenuState; }
		set { m_MenuState = value;}
	}


	void Awake()
	{
	}

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {


		switch(m_MenuState)
		{
			case MENU_STATE.MENU_STATE_NONE:
			{
				
			}break;
			case MENU_STATE.MENU_STATE_HELP:
			{
				animation.Play("CubeAnimRotate180");
				m_MenuState = MENU_STATE.MENU_STATE_NONE;

			}break;
			case MENU_STATE.MENU_STATE_ABOUT:
			{
				animation.Play("CubeAnimCredits");
				m_MenuState = MENU_STATE.MENU_STATE_NONE;
			}break;
			case MENU_STATE.MENU_STATE_HELP_TO_MAIN:
			{
				animation.Play("CubeAnimHelpToMain");
				m_MenuState = MENU_STATE.MENU_STATE_NONE;
			}break;
			case MENU_STATE.MENU_STATE_CREDITS_TO_MAIN:
			{
				animation.Play("CubeAnimCreditsToMain");
				m_MenuState = MENU_STATE.MENU_STATE_NONE;

			}break;
			case MENU_STATE.MENU_STATE_PLAY:
			{
				Application.LoadLevel("Level");
				m_MenuState = MENU_STATE.MENU_STATE_NONE;
			}break;


			default:break;
		}

	
	}
}
