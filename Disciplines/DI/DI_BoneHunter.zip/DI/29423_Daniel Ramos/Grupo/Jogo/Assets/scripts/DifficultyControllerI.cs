using System;

namespace AssemblyCSharp
{
	public interface DifficultyControllerI
	{
		void GenerateObjectivesPool(int gridSizeX, int gridSizeY);
		
		CubeProperties getObjectiveFromPool();
		int getNumObjectives();
	}
}

