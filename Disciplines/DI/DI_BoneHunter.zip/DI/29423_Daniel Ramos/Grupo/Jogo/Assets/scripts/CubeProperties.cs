using System;
using UnityEngine;

namespace AssemblyCSharp
{
	public struct CubeProperties
	{
		public Color cor;
		public GoType tipo;
		
	};
}

